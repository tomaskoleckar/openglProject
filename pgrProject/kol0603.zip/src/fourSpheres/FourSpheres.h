#pragma once
#include "../Scene/Scene.h"

class FourSpheresScene {
public:
    FourSpheresScene(Scene& scene) : m_scene(scene) {}
    void generate();

private:
    Scene& m_scene;
};

#pragma once

enum class ShadingMode {
    CONSTANT = 0,
    LAMBERT = 1,
    PHONG = 2,
    BLINN = 3
};

#include "Scene.h"
#include "../Renderer/Renderer.h"
#include "../transform/Translate.h"
#include "../transform/CompositeTransform.h"
#include "../transform/Scale.h"
#include "../transform/Rotate.h"

void Scene::addModel(std::shared_ptr<Model> model, bool withoutId)
{
    if (!withoutId)
        model->setID(nextID());

    m_models.push_back(std::move(model));
}

void Scene::render(Renderer& renderer)
{
    for (auto& m : m_models) {
        renderModelRecursive(renderer, m, glm::mat4(1.0f));
    }
}

void Scene::renderModelRecursive(Renderer& renderer,
    const std::shared_ptr<Model>& m,
    const glm::mat4& parentMat)
{
    glm::mat4 world = parentMat * m->transform();
    renderer.renderModel(*m, world);
    for (auto& child : m->children()) {
        renderModelRecursive(renderer, child, world);
    }
}

void Scene::select(int id)
{
    m_selectedID = id;

    for (auto& m : m_models) {
        if (m->id() == id)
            m->setColor(glm::vec3(1.0f, 0.2f, 0.2f));
        else
            m->setColor(glm::vec3(1.0f));
    }
}

Model* Scene::getSelected()
{
    if (m_selectedID < 0)
        return nullptr;

    for (auto& m : m_models) {
        if (m->id() == m_selectedID)
            return m.get();
    }
    return nullptr;
}

int Scene::nextID()
{
    return m_models.size() + 1;
}

void Scene::removeSelected()
{
    if (m_selectedID < 0) return;

    m_models.erase(
        std::remove_if(m_models.begin(), m_models.end(),
            [&](const std::shared_ptr<Model>& m) {
                return m->id() == m_selectedID;
            }),
        m_models.end()
    );

    m_selectedID = -1;
}

void Scene::spawnTreeAt(const glm::vec3& pos)
{
    if (!m_treeMesh)
        return;

    auto t = std::make_shared<CompositeTransform>();
    t->add(std::make_shared<Translate>(pos.x, 0.0f, pos.z));
    t->add(std::make_shared<Rotate>(0.0f, glm::vec3(0, 1, 0)));
    t->add(std::make_shared<Scale>(1.0f));

    auto model = std::make_shared<Model>(m_treeMesh);
    model->setTransform(t);
    model->setColor(glm::vec3(0.4f, 0.8f, 0.4f));

    Material wood;
    wood.ra = { 0.1f, 0.08f, 0.05f };
    wood.rd = { 0.4f, 0.3f, 0.2f };
    wood.rs = { 0.05f, 0.05f, 0.05f };
    wood.h = 8.0f;
    model->setMaterial(wood);

    if (m_treeTexture)
        wood.setTexture(m_treeTexture);

    addModel(model);
}

void Scene::removeByID(int id)
{
    m_models.erase(
        std::remove_if(m_models.begin(), m_models.end(),
            [id](const std::shared_ptr<Model>& m) {
                return m->id() == id;
            }),
        m_models.end()
    );

    if (m_selectedID == id)
        m_selectedID = -1;
}

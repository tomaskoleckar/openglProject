#include "ObjLoader.h"
#include "tinyObjectLoader/tiny_obj_loader.h"
#include <glm/glm.hpp>
#include <limits>
#include <stdexcept>


std::vector<MeshWithTexture> loadOBJWithMaterials(const std::string& path, const std::string& baseDir)
{
    tinyobj::ObjReader reader;
    tinyobj::ObjReaderConfig config;
    config.mtl_search_path = baseDir;
    config.triangulate = true;

    if (!reader.ParseFromFile(path, config)) {
        if (!reader.Error().empty())
            throw std::runtime_error("OBJ load error: " + reader.Error());
        throw std::runtime_error("OBJ load failed (unknown error).");
    }

    const auto& attrib = reader.GetAttrib();
    const auto& shapes = reader.GetShapes();
    const auto& materials = reader.GetMaterials();

    std::vector<MeshWithTexture> result;

    for (const auto& shape : shapes)
    {
        std::vector<float> interleaved;
        interleaved.reserve(shape.mesh.indices.size() * 8);

        for (size_t i = 0; i < shape.mesh.indices.size(); i++)
        {
            tinyobj::index_t idx = shape.mesh.indices[i];
            glm::vec3 pos(
                attrib.vertices[3 * idx.vertex_index + 0],
                attrib.vertices[3 * idx.vertex_index + 1],
                attrib.vertices[3 * idx.vertex_index + 2]);

            glm::vec3 nrm(0, 1, 0);
            if (idx.normal_index >= 0 && idx.normal_index * 3 + 2 < attrib.normals.size()) {
                nrm = glm::vec3(
                    attrib.normals[3 * idx.normal_index + 0],
                    attrib.normals[3 * idx.normal_index + 1],
                    attrib.normals[3 * idx.normal_index + 2]);
            }

            glm::vec2 uv(0.0f);
            if (idx.texcoord_index >= 0 && (size_t)(2 * idx.texcoord_index + 1) < attrib.texcoords.size()) {
                uv = glm::vec2(
                    attrib.texcoords[2 * idx.texcoord_index + 0],
                    1.0f - attrib.texcoords[2 * idx.texcoord_index + 1]); 
            }

            interleaved.insert(interleaved.end(),
                { pos.x, pos.y, pos.z, nrm.x, nrm.y, nrm.z, uv.x, uv.y });
        }

        int mat_id = (shape.mesh.material_ids.empty() ? -1 : shape.mesh.material_ids[0]);
        std::string texPath;
        if (mat_id >= 0 && mat_id < materials.size()) {
            texPath = materials[mat_id].diffuse_texname;
        }

        auto mesh = std::make_shared<Mesh>(interleaved, true, true, std::vector<unsigned int>());
        result.push_back({ mesh, texPath });
    }

    return result;
}


static inline glm::vec3 safeNormalize(const glm::vec3& v) {
    float l = glm::length(v);
    return (l > 1e-8f) ? (v / l) : glm::vec3(0, 1, 0);
}

std::shared_ptr<Mesh> loadOBJ(const std::string& path, bool autoScale)
{
    tinyobj::ObjReader reader;
    tinyobj::ObjReaderConfig config;
    config.mtl_search_path = "";
    config.triangulate = true;

    if (!reader.ParseFromFile(path, config)) {
        if (!reader.Error().empty())
            throw std::runtime_error("OBJ load error: " + reader.Error());
        throw std::runtime_error("OBJ load failed (unknown error).");
    }

    const auto& attrib = reader.GetAttrib();
    const auto& shapes = reader.GetShapes();

    bool hasNormals = !attrib.normals.empty();

    std::vector<float> interleaved;

    glm::vec3 bbMin(+std::numeric_limits<float>::max());
    glm::vec3 bbMax(-std::numeric_limits<float>::max());

    std::vector<glm::vec3> accumNormals(attrib.vertices.size() / 3, glm::vec3(0));
    if (!hasNormals) {
        size_t index_offset = 0;
        for (const auto& s : shapes) {
            for (size_t f = 0; f < s.mesh.num_face_vertices.size(); f++) {
                const size_t fv = s.mesh.num_face_vertices[f];
                if (fv != 3) { index_offset += fv; continue; }

                tinyobj::index_t i0 = s.mesh.indices[index_offset + 0];
                tinyobj::index_t i1 = s.mesh.indices[index_offset + 1];
                tinyobj::index_t i2 = s.mesh.indices[index_offset + 2];

                glm::vec3 p0(
                    attrib.vertices[3 * i0.vertex_index + 0],
                    attrib.vertices[3 * i0.vertex_index + 1],
                    attrib.vertices[3 * i0.vertex_index + 2]);
                glm::vec3 p1(
                    attrib.vertices[3 * i1.vertex_index + 0],
                    attrib.vertices[3 * i1.vertex_index + 1],
                    attrib.vertices[3 * i1.vertex_index + 2]);
                glm::vec3 p2(
                    attrib.vertices[3 * i2.vertex_index + 0],
                    attrib.vertices[3 * i2.vertex_index + 1],
                    attrib.vertices[3 * i2.vertex_index + 2]);

                glm::vec3 n = glm::normalize(glm::cross(p1 - p0, p2 - p0));
                accumNormals[i0.vertex_index] += n;
                accumNormals[i1.vertex_index] += n;
                accumNormals[i2.vertex_index] += n;

                index_offset += fv;
            }
        }
        for (auto& an : accumNormals) an = safeNormalize(an);
    }

    for (const auto& s : shapes) {
        size_t index_offset = 0;
        for (size_t f = 0; f < s.mesh.num_face_vertices.size(); f++) {
            const size_t fv = s.mesh.num_face_vertices[f];
            for (size_t v = 0; v < fv; v++) {
                size_t idxIndex = index_offset + v;
                if (idxIndex >= s.mesh.indices.size())
                    continue;

                tinyobj::index_t idx = s.mesh.indices[idxIndex];

                if (idx.vertex_index < 0 || idx.vertex_index * 3 + 2 >= attrib.vertices.size())
                    continue;

                glm::vec3 pos(
                    attrib.vertices[3 * idx.vertex_index + 0],
                    attrib.vertices[3 * idx.vertex_index + 1],
                    attrib.vertices[3 * idx.vertex_index + 2]);

                glm::vec3 nrm(0, 1, 0);
                if (idx.normal_index >= 0 && (idx.normal_index * 3 + 2) < attrib.normals.size()) {
                    nrm = glm::vec3(
                        attrib.normals[3 * idx.normal_index + 0],
                        attrib.normals[3 * idx.normal_index + 1],
                        attrib.normals[3 * idx.normal_index + 2]
                    );
                    nrm = safeNormalize(nrm);
                }
                else {
                    nrm = accumNormals[idx.vertex_index];
                }

                glm::vec2 uv(0.0f);
                if (idx.texcoord_index >= 0 && (idx.texcoord_index * 2 + 1) < attrib.texcoords.size()) {
                    uv = glm::vec2(
                        attrib.texcoords[2 * idx.texcoord_index + 0],
                        attrib.texcoords[2 * idx.texcoord_index + 1]
                    );
                }

                bbMin = glm::min(bbMin, pos);
                bbMax = glm::max(bbMax, pos);

                interleaved.push_back(pos.x);
                interleaved.push_back(pos.y);
                interleaved.push_back(pos.z);
                interleaved.push_back(nrm.x);
                interleaved.push_back(nrm.y);
                interleaved.push_back(nrm.z);
                interleaved.push_back(uv.x);
                interleaved.push_back(uv.y);
            }
            index_offset += fv;
            if (index_offset > s.mesh.indices.size()) break;
        }
    }

    if (autoScale && !interleaved.empty()) {
        glm::vec3 size = bbMax - bbMin;
        float maxAxis = std::max(size.x, std::max(size.y, size.z));
        if (maxAxis > 1e-6f) {
            glm::vec3 center = (bbMax + bbMin) * 0.5f;
            float s = 1.0f / maxAxis;
            for (size_t i = 0; i < interleaved.size(); i += 8) {
                glm::vec3 p(interleaved[i + 0], interleaved[i + 1], interleaved[i + 2]);
                p = (p - center) * s;
                interleaved[i + 0] = p.x;
                interleaved[i + 1] = p.y;
                interleaved[i + 2] = p.z;
            }
        }
    }

    if (interleaved.empty())
        throw std::runtime_error("OBJ has no triangles: " + path);

    return std::make_shared<Mesh>(interleaved, true, true);
}

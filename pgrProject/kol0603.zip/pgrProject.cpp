#include "src/Application/Application.h"


int main() {
	Application app(1280, 720);
	app.run();
	return 0;
}